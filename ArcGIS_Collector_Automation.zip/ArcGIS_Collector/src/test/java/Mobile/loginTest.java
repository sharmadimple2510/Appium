package Mobile;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class loginTest {
	/* Testcases Covered in this class
	 
	 1.Install the app
	 2.Start the application
	 3.Login with Incorrect Credentials > capture
	 4.Login with Correct Credentials > capture
	
	*/
	@BeforeTest
	public void Appiumstart() throws IOException, InterruptedException
	{
		Runtime.getRuntime().exec("cmd /c start C:/Appium/StartAppiumServer.bat");
		Thread.sleep(10000);
		System.out.println("Appium started");
	}

	  @Test
		public void LaunchCollectorApplication() throws InterruptedException, IOException {
		// below are the capabilities passed at the start of execution only
			File AppDir = new File("src");
			File app = new File(AppDir, "ArcGISCollector-release.apk");
			DesiredCapabilities cap=new DesiredCapabilities();
			cap.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
			cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Device");
			cap.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
			
		//This will avoid the timeout error for launch of start activity
			
			cap.setCapability(MobileCapabilityType.APP_WAIT_ACTIVITY,"com.esri.arcgis.app.views.accounts.StartScreenActivity");
			
		//This will avoid the timeout error if the page takes longer time to load
			cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "1000");
		
		//Android Driver
			AndroidDriver driver =new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),cap);
			Thread.sleep(5000);
		//clicking on "Continue"
			driver.findElementById("com.esri.arcgis.collector:id/sign_in_continue_button").click();
			Thread.sleep(2000);
			driver.findElements(By.className("android.widget.EditText")).size();
			Thread.sleep(2000);
			
		//login to application with Incorrect details
		
			List<WebElement> a=driver.findElements(By.className("android.widget.EditText"));
			Thread.sleep(1000);
			a.get(0).sendKeys("San");
			Thread.sleep(1000);
			a.get(1).sendKeys("tes");
			Thread.sleep(2000);
			driver.findElementByClassName("android.widget.Button").click();
			Thread.sleep(2000);
		// Capturing the login failed error
			File scrfile=driver.getScreenshotAs(OutputType.FILE);
			String fileName =UUID.randomUUID().toString();
			File targetFile =new File("/AppiumTest/Result_snap/" + fileName + ".jpg");
			FileUtils.copyFile(scrfile, targetFile);
			System.out.println(targetFile);
			Thread.sleep(2000);
		// Android key events
			 driver.sendKeyEvent(AndroidKeyCode.BACK);
			 Thread.sleep(2000);
			 driver.findElementById("com.esri.arcgis.collector:id/sign_in_continue_button").click();
			 Thread.sleep(2000);
		
		//login to application with correct details
			
		//List<WebElement> a=driver.findElements(By.className("android.widget.EditText"));
			a.get(0).sendKeys("Sanity");
			Thread.sleep(1000);
			a.get(1).sendKeys("bazinga");
			Thread.sleep(1000);
			driver.findElementByClassName("android.widget.Button").click();
			System.out.println("Log in successful");
			Thread.sleep(1000);
		
				
				
}

}
