package Mobile;
import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeTest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.SwipeElementDirection;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class mobilefeature {

	@BeforeTest
	public void Appiumstart() throws IOException, InterruptedException
	{
		Runtime.getRuntime().exec("cmd /c start C:/Appium/StartAppiumServer.bat");
		Thread.sleep(7000);
		System.out.println("Appium started");
	}

	@Test
	public void test() throws InterruptedException, IOException {
	// below are the capabilities passed at the start of execution only
		
		File AppDir = new File("src");
		File app = new File(AppDir, "ArcGISCollector-release.apk");
		DesiredCapabilities cap=new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Device");
		cap.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
	//This will avoid the timeout error for launch of start activity */
		cap.setCapability(MobileCapabilityType.APP_WAIT_ACTIVITY,"com.esri.arcgis.app.views.accounts.StartScreenActivity");
	//This will avoid the timeout error if the page takes longer time to load
		cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "1000");
	
	//Android Driver
		AndroidDriver driver =new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),cap);
		
	//clicking on "Continue"
		driver.findElementById("com.esri.arcgis.collector:id/sign_in_continue_button").click();
		driver.findElements(By.className("android.widget.EditText")).size();
		Thread.sleep(1000);
	//System.out.println(s);
		
	//login to application with correct details
		List<WebElement> a=driver.findElements(By.className("android.widget.EditText"));
		a.get(0).sendKeys("Sanity");
		a.get(1).sendKeys("bazinga");
		driver.findElementByClassName("android.widget.Button").click();
		Thread.sleep(2000);
		
	//Code for Swipe
		 
		MobileElement mob =(MobileElement)driver.findElementByName("Measure Tool");
		mob.swipe(SwipeElementDirection.UP,70000);
		
	
		
		
	}
}