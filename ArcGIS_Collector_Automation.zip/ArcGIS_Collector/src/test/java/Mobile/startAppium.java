package Mobile;

import java.io.IOException;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class startAppium {
	@BeforeTest
	public void Appiumstart() throws IOException, InterruptedException
	{
		Runtime.getRuntime().exec("cmd /c start C:/Appium/StartAppiumServer.bat");
		Thread.sleep(7000);
		System.out.println("Appium started");
	}

}
