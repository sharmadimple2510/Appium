package Mobile;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class switchAccount {
	@BeforeTest
	public void Appiumstart() throws IOException, InterruptedException
	{
		Runtime.getRuntime().exec("cmd /c start C:/Appium/StartAppiumServer.bat");
		Thread.sleep(10000);
		System.out.println("Appium started");
	}
	@Test
	public void SwicthAccount() throws InterruptedException, IOException {
			// below are the capabilities passed at the start of execution only
				File AppDir = new File("src");
				File app = new File(AppDir, "ArcGISCollector-release.apk");
				DesiredCapabilities cap=new DesiredCapabilities();
				cap.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
				cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Device");
				cap.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
				
			//This will avoid the timeout error for launch of start activity
				
				cap.setCapability(MobileCapabilityType.APP_WAIT_ACTIVITY,"com.esri.arcgis.app.views.accounts.StartScreenActivity");
				
			//This will avoid the timeout error if the page takes longer time to load
				cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "1000");
			
			//Android Driver
				AndroidDriver driver =new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),cap);
				Thread.sleep(50000);
			//clicking on "Continue"
				driver.findElementById("com.esri.arcgis.collector:id/sign_in_continue_button").click();
				Thread.sleep(2000);
				driver.findElements(By.className("android.widget.EditText")).size();
				Thread.sleep(2000);
			// Login in with correct Credentials
				
				List<WebElement> a=driver.findElements(By.className("android.widget.EditText"));
				a.get(0).sendKeys("Sanity");
				a.get(1).sendKeys("bazinga");
				Thread.sleep(2000);
				driver.findElementByClassName("android.widget.Button").click();
				System.out.println("Log in successful");
				Thread.sleep(50000);
			// Code for SwicthAccount TestCase
				 
				driver.findElementByClassName("android.widget.ImageButton").click();
				Thread.sleep(2000);
				driver.scrollTo("Switch Account").click();
				Thread.sleep(50000);
				driver.findElementById("com.esri.arcgis.collector:id/account_dialog_item_overflow_imageview").click();
				Thread.sleep(2000);
				driver.scrollTo("Remove").click();
				Thread.sleep(2000);
				driver.findElementById("android:id/button1").click();
				Thread.sleep(50000);
				System.out.println("Account removed Successfully");
				//clicking on "Continue"
				driver.findElementById("com.esri.arcgis.collector:id/sign_in_continue_button").click();
				Thread.sleep(2000);
				driver.findElements(By.className("android.widget.EditText")).size();
				Thread.sleep(2000);
			
			
			//login to application with correct details
				
				
				//List<WebElement> a1=driver.findElements(By.className("android.widget.EditText"));
				a.get(0).sendKeys("Sanity");
				Thread.sleep(2000);
				a.get(1).sendKeys("bazinga");
				Thread.sleep(2000);
				driver.findElementByClassName("android.widget.Button").click();
				System.out.println("Log in successful");
				Thread.sleep(50000);
			
			//Code for **About** page Snapshot 
				
				driver.findElementByClassName("android.widget.ImageButton").click();
				Thread.sleep(2000);
				driver.scrollTo("About").click();
				Thread.sleep(2000);
				File scrfile=driver.getScreenshotAs(OutputType.FILE);
				String fileName =UUID.randomUUID().toString();
				File targetFile =new File("/AppiumTest/Result_snap/" + fileName + ".jpg");
				FileUtils.copyFile(scrfile, targetFile);
				System.out.println(targetFile);
				Thread.sleep(2000);
				
			// Android key events
				 driver.sendKeyEvent(AndroidKeyCode.BACK);
				 Thread.sleep(500);
				 
			//Checking contents under all map
				  	driver.findElementByName("All Maps").click();
					List<WebElement> c1=driver.findElementsById("com.esri.arcgis.collector:id/title_bar_info_textview");
					System.out.println("Number of Maps conunt in ALL maps=" + c1.get(0).getText());;
					
			// Open the 1st map under My Maps
					List<WebElement> p=driver.findElementsById("com.esri.arcgis.collector:id/portal_item");
					p.get(1).click();
					Thread.sleep(1000);
	}
	

}
