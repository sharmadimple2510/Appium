package Mobile;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class freshInstall {
	
	@BeforeTest
	public void Appiumstart() throws IOException, InterruptedException
	{
		Runtime.getRuntime().exec("cmd /c start C:/Appium/StartAppiumServer.bat");
		Thread.sleep(10000);
		System.out.println("Appium started");
	}
	@Test
	public void Collector() throws InterruptedException, IOException {
	//below are the capabilities passed at the start of execution only
		File AppDir = new File("src");
		File app = new File(AppDir, "ArcGISCollector-release.apk");
		DesiredCapabilities cap=new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
		cap.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
		
	//This will avoid the timeout error for launch of start activity
		cap.setCapability(MobileCapabilityType.APP_WAIT_ACTIVITY,"com.esri.arcgis.app.views.accounts.StartScreenActivity");
	//cap.setCapability(MobileCapabilityType.APP_WAIT_ACTIVITY,"com.esri.arcgis.collector/com.esri.arcgis.app.framework.FirstActivity");
		
	//This will avoid the timeout error if the page takes longer time to load
		cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "1000");
	
	//Android Driver
		AndroidDriver driver =new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),cap);
		Thread.sleep(10000);
	//check learn more page
		driver.findElementById("com.esri.arcgis.collector:id/learn_more_textView").click();
		Thread.sleep(10000);
	//Capture Screenshot of "Learn more page"
		File scrfile=driver.getScreenshotAs(OutputType.FILE);
		String fileName =UUID.randomUUID().toString();
		File targetFile =new File("/AppiumTest/Result_snap/" + fileName + ".jpg");
		FileUtils.copyFile(scrfile, targetFile);
		System.out.println(targetFile);
		
		driver.closeApp();
		Thread.sleep(5000);
		driver.launchApp();
		Thread.sleep(1000);
	//check try collector for ArcGIS page
		driver.findElementById("com.esri.arcgis.collector:id/sign_in_title_textView").click();
		Thread.sleep(1000);
		driver.findElementByAndroidUIAutomator("new UiSelector().text(\"All Maps\")").click();
		Thread.sleep(1000);
	// Open map under "All map"
		List<WebElement> p=driver.findElementsById("com.esri.arcgis.collector:id/portal_item");
		p.get(1).click();
		Thread.sleep(1000);
	}
	}
